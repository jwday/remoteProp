# remoteProp
Sets up MQTT broker on a computer, an MQTT client on a browser, and an MQTT client on an ESP8266.
Using the web client you can control an LED attached to the ESP8266.
